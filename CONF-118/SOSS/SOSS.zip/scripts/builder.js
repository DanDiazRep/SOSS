﻿//GET DATA
var data = getData;

//Menu building variables
var canvas = document.getElementById('builderCanvas');

//********************* BABYLON ENGINE INITIALIZATION *****************

var engine = new BABYLON.Engine(canvas, true, { premultipliedAlpha: false, preserveDrawingBuffer: true, stencil: true });
var scene = new BABYLON.Scene(engine);
var hinge;
var animationGroup;
var isOpen = false;
var isWoodBlock = true;
var hingeMaterial = "Chrome";
var root;
if (window.location.hostname != "localhost") {
    root = window.location.href.replace("index.html", "");    
    if (root.includes("#")) {
        root = root.replace("#", "");
    }
}
else {
    root = window.location.origin;;
}
//Background setup
scene.clearColor = new BABYLON.Color3(0.95, 0.95, 0.95); //Background color


 //Prototypes
BABYLON.ArcRotateCamera.prototype.spinTo = function (whichprop, targetval, speed) {
    var ease = new BABYLON.CubicEase();
    ease.setEasingMode(BABYLON.EasingFunction.EASINGMODE_EASEINOUT);
    BABYLON.Animation.CreateAndStartAnimation('at4', this, whichprop, speed, 120, this[whichprop], targetval, 0, ease);
}

//Scene creation
var createScene = function () {

    // Assets loader
   var path = root + data.ModelPath;
   var model = data.Model;  

    //Adding an Arc Rotate Camera
    var camera = new BABYLON.ArcRotateCamera("Camera", (Math.PI * 0.8), (8 * Math.PI / 16), 4, new BABYLON.Vector3(0, 0, 0), scene);
    camera.attachControl(canvas, false);
    camera.lowerRadiusLimit = 2.3;
    camera.upperRadiusLimit = 6;
    camera.panningSensibility = 1000;
    camera.wheelPrecision = 100;


    //Adding an hemispheric light
    var light = new BABYLON.HemisphericLight("omni", new BABYLON.Vector3(0, 2, 0), scene);
    light.intensity = 1;
    //Adding a point light
    var light = new BABYLON.PointLight("pl", camera.position, scene);
    light.intensity = 1;

    BABYLON.SceneLoader.ShowLoadingScreen = false;
    BABYLON.SceneLoader.Append(path, model, scene, function (meshes) {
        hinge = meshes;
        var aoImages = new BABYLON.Texture("", scene);
        for (meshes = 1; hinge.meshes.length > meshes; meshes++) {
            hinge.meshes[meshes].actionManager = new BABYLON.ActionManager(scene); // Pointer behavior on model hover                       
            hinge.meshes[meshes].actionManager.registerAction(new BABYLON.ExecuteCodeAction(BABYLON.ActionManager.OnPointerOverTrigger, function (ev) {
            }, false));    
            //Preloading AO Images
            for (meshes = 1; hinge.meshes.length > meshes; meshes++) {
                aoImages << new BABYLON.Texture(`./assets/materials/aoOpen/${hinge.meshes[meshes].name}_Mixed_AO.png`, scene);
                aoImages << new BABYLON.Texture(`./assets/materials/aoClosed/${hinge.meshes[meshes].name}_Mixed_AO.png`, scene);                
            }
        }
        //Animation handling
        hinge.animationsEnabled = true;
        animationGroup = hinge.animationGroups[0];
        animationGroup.loopAnimation = false;
        isOpen = true;
        var lastAnim = 0;

        animationGroup.onAnimationGroupPlayObservable.add(function () {
            
            if (!isWoodBlock) {
                while (lastAnim < 1) {
                    for (meshes = 1; hinge.meshes.length > meshes; meshes++) {
                        hinge.meshes[meshes].material.ambientTexture =
                            new BABYLON.Texture(`./assets/materials/aoOpen/${hinge.meshes[meshes].name}_Mixed_AO.png`, scene);
                        hinge.meshes[meshes].material.ambientTexture.vAng = -Math.PI;
                        hinge.meshes[meshes].material.ambientTexture.wAng = -Math.PI;

                    }
                    lastAnim++;
                }
            }
            
        });
        animationGroup.onAnimationEndObservable.add(function () {
            $("#playAnimation").css("background", " #CD3327");
        });

        //Env texture
        /*var hdrTexture = new BABYLON.CubeTexture.CreateFromPrefilteredData("./assets/environment/default.dds", scene);
        hdrTexture.gammaSpace = true;
        scene.environmentTexture = hdrTexture;*/        
        var helper = scene.createDefaultEnvironment();
        helper.setMainColor(BABYLON.Color3.White());
        

    }
    );    
    console.log(scene);
    window.addEventListener("resize", function () { engine.resize(); });
    return scene;
}


// call the createScene function
var scene = createScene();


// run the render loop
engine.runRenderLoop(function () {
    window.addEventListener("resize", function () { engine.resize(); });
    scene.render();
});


function playAnimation() {
    if (!animationGroup.isPlaying) {
        $("#playAnimation").css("background", "#a2281f");
        if (isOpen) {
            //Play Animation Forward
            animationGroup.start(false, -1, 4, 0);            
        }
        else {
            //Play Animation Backwards
            animationGroup.start(false, 1, 0, 4);
        }
        isOpen = !isOpen;
    }

    
}

function woodBlockState() {
    for (meshes = 1; hinge.meshes.length > meshes; meshes++) {
        if (!hinge.meshes[meshes].name.includes("Background")) {
            //Toggle the wood block visibility
            if (hinge.meshes[meshes].name.includes("Wood"))
                hinge.meshes[meshes].visibility = !hinge.meshes[meshes].visibility;

            // remove Ambient Occlusion when there is not a wood block
            hinge.meshes[meshes].material.ambientTexture = null;
        }

        $("#woodState").text(`${isWoodBlock ? "Show" : "Hide"} Wood Block`);

        $("#woodImage").attr("src", `./assets/layout/${isWoodBlock ? "show" : "hide"}.png`);

        isWoodBlock = !isWoodBlock;
        if (isWoodBlock && isOpen) {
            scene.activeCamera.spinTo("alpha", (Math.PI * 0.8), 60);
            scene.activeCamera.spinTo("beta", (8 * Math.PI / 16), 60);
            scene.activeCamera.spinTo("radius", 4, 60);
        }
    }
}

function materialChange(material) {

    if (material != hingeMaterial) {

        $(`#${material}`).detach().prependTo("#materialChange");
        //$(`#Chrome`).css("display", "none");
       // $(`#Nickel`).css("display", "none");
        
        $(`#${material}`).css("display", "inline-block");
        
        for (meshes = 1; hinge.meshes.length > meshes; meshes++) {
            if (!hinge.meshes[meshes].name.includes("Wood") && !(hinge.meshes[meshes].name.includes("Background")))
                hinge.meshes[meshes].material.albedoTexture =
                    new BABYLON.Texture(`./assets/materials/satin${material}/${hinge.meshes[meshes].name}_Base_Color.png`, scene);
        }
        hingeMaterial = material;
    }



}
var coll = document.getElementsByClassName("collapsible");
