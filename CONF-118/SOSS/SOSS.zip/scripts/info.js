﻿

var getData =
{
    "Code": "soss",
    "Description": "Invinsible Hinge",
    "ModelPath": "/assets/models/",
    "Model": "hinge.glb",
    "DefaultLayers": [        
        ""
    ],
}
