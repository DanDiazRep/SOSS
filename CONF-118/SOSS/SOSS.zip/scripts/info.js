﻿

var data =
{
    "Code": "soss",
    "Description": "Invinsible Hinge",
    "ModelPath": "/assets/models/",
    "Model": "hinge.glb",
    "Skybox": "./assets/env/CathedralEnvHDR.dds",
    "Background": "assets/environment/background.jpg",
}
